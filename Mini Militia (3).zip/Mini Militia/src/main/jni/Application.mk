APP_ABI := armeabi-v7a
APP_PLATFORM := android-24
APP_STL := c++_static
APP_OPTIM := release
APP_THIN_ARCHIVE := true
APP_PIE := true