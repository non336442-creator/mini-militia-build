#include <jni.h>
#include <pthread.h>
#include <dlfcn.h>
#include <unistd.h>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <mutex>

#include <android/log.h>
#include <android/input.h>
#include <GLES3/gl3.h>
#include <EGL/egl.h>


#include "xdl.h"
#include "dobby.h"
#include "imgui.h"
#include "imgui_impl_opengl3.h"
#include "imgui_impl_android.h"


#define LIB "libcocos2dcpp.so"
#define LOG_TAG "UMT_Native"


bool MOpen = true;
bool HActive = false;
bool HooksAttempted = false;
int  ScreenWidth = 0;
int  ScreenHeight = 0;


struct {
    bool InfiniteAmmo = false;
    bool HighDamage   = false;
    bool InstantReload= false;
    bool MegaClip     = false;
    bool InfiniteHealth = false;
    bool InfiniteJetpack = false;
    bool EspBox = false;
    bool EspLine = false;
    bool EspHealth = false;
    bool Aimbot = false;
} Cheat;





void (*old_Weapon_subAmmo)(void*, int);
void hk_Weapon_subAmmo(void* instance, int amount) {
    if (Cheat.InfiniteAmmo)
        return;
    if (old_Weapon_subAmmo) old_Weapon_subAmmo(instance, amount);
}

float (*old_Weapon_getDamage)(void*);
float hk_Weapon_getDamage(void* instance) {
    if (Cheat.HighDamage)
        return 99999.0f;
    if (old_Weapon_getDamage) return old_Weapon_getDamage(instance);
    return 10.0f;
}

float (*old_Weapon_getReloadTime)(void*);
float hk_Weapon_getReloadTime(void* instance) {
    if (Cheat.InstantReload)
        return 0.0f;
    if (old_Weapon_getReloadTime) return old_Weapon_getReloadTime(instance);
    return 2.5f;
}

int (*old_Weapon_getClipCapacity)(void*);
int hk_Weapon_getClipCapacity(void* instance) {
    if (Cheat.MegaClip)
        return 1000;
    if (old_Weapon_getClipCapacity) return old_Weapon_getClipCapacity(instance);
    return 30;
}

// The positions in this ARMv7 game are two doubles (Chipmunk cpVect).
struct GamePosition {
    double x;
    double y;
};

// Cocos2d-x CCPoint is two floats.
struct GamePoint {
    float x;
    float y;
};

void* LocalPlayer = nullptr;
std::vector<void*> RemotePlayers;
std::mutex RemotePlayersMutex;

// Game functions: resolved from the exact exported symbols in libcocos2dcpp.so.
void* (*getHostController)(void*) = nullptr;
GamePosition (*getBodyPosition)(void*) = nullptr;
void* (*getSoldierView)(void*) = nullptr;
int (*getPlayerHP)(void*) = nullptr;
int (*getHostHP)(void*) = nullptr;
void (*setHostHP)(void*, int) = nullptr;
int (*getMaxPower)(void*) = nullptr;
float (*getHostPower)(void*) = nullptr;
void (*setHostPower)(void*, float) = nullptr;
void (*setHostFireAngle)(void*, float) = nullptr;
void (*setViewFiringAngle)(void*, float) = nullptr;
int (*getTeamId)(void*) = nullptr;
bool (*isSameTeam)(void*, int) = nullptr;
bool (*isPlayerDead)(void*) = nullptr;
GamePoint (*convertToWorldSpace)(void*, const GamePoint&) = nullptr;
GamePoint (*convertToNodeSpace)(void*, const GamePoint&) = nullptr;
void (*ccDrawLine)(const GamePoint&, const GamePoint&) = nullptr;
void (*ccDrawColor4B)(unsigned char, unsigned char, unsigned char, unsigned char) = nullptr;

bool IsEnemy(void* player) {
    if (!player || player == LocalPlayer) return false;
    if (isPlayerDead && isPlayerDead(player)) return false;
    if (LocalPlayer && getTeamId && isSameTeam) {
        int team = getTeamId(player);
        if (team > 0 && isSameTeam(LocalPlayer, team)) return false;
    }
    return true;
}

// Collect remote controllers during their normal update; delete stale entries on destruction.
void (*old_Remote_updateStep)(void*, float) = nullptr;
void hk_Remote_updateStep(void* instance, float delta) {
    if (old_Remote_updateStep) old_Remote_updateStep(instance, delta);
    if (!instance) return;
    std::lock_guard<std::mutex> lock(RemotePlayersMutex);
    if (std::find(RemotePlayers.begin(), RemotePlayers.end(), instance) == RemotePlayers.end()
        && RemotePlayers.size() < 64) {
        RemotePlayers.push_back(instance);
    }
}

void (*old_Remote_destructor)(void*) = nullptr;
void hk_Remote_destructor(void* instance) {
    {
        std::lock_guard<std::mutex> lock(RemotePlayersMutex);
        RemotePlayers.erase(std::remove(RemotePlayers.begin(), RemotePlayers.end(), instance), RemotePlayers.end());
    }
    if (old_Remote_destructor) old_Remote_destructor(instance);
}

// These features run on the game update thread, not inside the ImGui UI callback.
void (*old_Manager_updateStep)(void*, float) = nullptr;
void hk_Manager_updateStep(void* instance, float delta) {
    if (old_Manager_updateStep) old_Manager_updateStep(instance, delta);
    if (!instance || !getHostController) return;

    LocalPlayer = getHostController(instance);
    if (!LocalPlayer) return;

    if (Cheat.InfiniteHealth && getHostHP && setHostHP) {
        int hp = getHostHP(LocalPlayer);
        if (hp > 0 && hp < 100) setHostHP(LocalPlayer, 100);
    }

    if (Cheat.InfiniteJetpack && getHostPower && setHostPower && getMaxPower) {
        int maxPower = getMaxPower(LocalPlayer);
        if (maxPower > 0 && maxPower <= 10000) {
            float power = getHostPower(LocalPlayer);
            if (std::isfinite(power) && power < float(maxPower))
                setHostPower(LocalPlayer, float(maxPower));
        }
    }

    if (!Cheat.Aimbot || !getBodyPosition || !setHostFireAngle) return;
    GamePosition me = getBodyPosition(LocalPlayer);
    if (!std::isfinite(me.x) || !std::isfinite(me.y)) return;

    void* nearest = nullptr;
    double nearestDistance = 1.0e100;
    GamePosition nearestPosition{};
    std::lock_guard<std::mutex> lock(RemotePlayersMutex);
    for (void* player : RemotePlayers) {
        if (!IsEnemy(player)) continue;
        GamePosition pos = getBodyPosition(player);
        if (!std::isfinite(pos.x) || !std::isfinite(pos.y)) continue;
        double dx = pos.x - me.x;
        double dy = pos.y - me.y;
        double distance = dx * dx + dy * dy;
        if (distance > 0.001 && distance < nearestDistance) {
            nearest = player;
            nearestDistance = distance;
            nearestPosition = pos;
        }
    }
    if (!nearest) return;
    float angle = std::atan2(float(nearestPosition.y - me.y),
                             float(nearestPosition.x - me.x));
    setHostFireAngle(LocalPlayer, angle);
    if (setViewFiringAngle && getSoldierView) {
        void* view = getSoldierView(LocalPlayer);
        if (view) setViewFiringAngle(view, angle);
    }
}

void DrawESP(void* stage) {
    if (!stage || !LocalPlayer || !getSoldierView || !convertToWorldSpace ||
        !convertToNodeSpace || !ccDrawLine || !ccDrawColor4B) return;
    if (!Cheat.EspBox && !Cheat.EspLine && !Cheat.EspHealth) return;

    void* myView = getSoldierView(LocalPlayer);
    if (!myView) return;
    GamePoint center{0.0f, 0.0f};
    GamePoint myWorld = convertToWorldSpace(myView, center);
    GamePoint myPoint = convertToNodeSpace(stage, myWorld);
    if (!std::isfinite(myPoint.x) || !std::isfinite(myPoint.y)) return;

    std::lock_guard<std::mutex> lock(RemotePlayersMutex);
    for (void* player : RemotePlayers) {
        if (!IsEnemy(player)) continue;
        void* view = getSoldierView(player);
        if (!view) continue;
        GamePoint world = convertToWorldSpace(view, center);
        GamePoint pos = convertToNodeSpace(stage, world);
        if (!std::isfinite(pos.x) || !std::isfinite(pos.y)) continue;
        if (std::abs(pos.x) > 30000.0f || std::abs(pos.y) > 30000.0f) continue;

        const float halfWidth = 15.0f;
        const float halfHeight = 25.0f;
        ccDrawColor4B(255, 60, 60, 255);
        if (Cheat.EspLine) ccDrawLine(myPoint, pos);
        if (Cheat.EspBox) {
            GamePoint a{pos.x - halfWidth, pos.y - halfHeight};
            GamePoint b{pos.x + halfWidth, pos.y - halfHeight};
            GamePoint c{pos.x + halfWidth, pos.y + halfHeight};
            GamePoint d{pos.x - halfWidth, pos.y + halfHeight};
            ccDrawLine(a, b);
            ccDrawLine(b, c);
            ccDrawLine(c, d);
            ccDrawLine(d, a);
        }
        if (Cheat.EspHealth && getPlayerHP) {
            int hp = getPlayerHP(player);
            if (hp < 0) hp = 0;
            if (hp > 100) hp = 100;
            float left = pos.x - halfWidth;
            float top = pos.y + halfHeight + 5.0f;
            ccDrawColor4B(80, 20, 20, 255);
            ccDrawLine(GamePoint{left, top}, GamePoint{left + 30.0f, top});
            ccDrawColor4B(30, 220, 80, 255);
            ccDrawLine(GamePoint{left, top}, GamePoint{left + 0.3f * hp, top});
        }
    }
    ccDrawColor4B(255, 255, 255, 255);
}

void (*old_Stage_draw)(void*) = nullptr;
void hk_Stage_draw(void* instance) {
    if (old_Stage_draw) old_Stage_draw(instance);
    DrawESP(instance);
}

bool InjectHook(const char* symbol, void* hookFun, void** oldfunc) {
    void* addr = DobbySymbolResolver(LIB, symbol);
    if (addr && DobbyHook(addr, hookFun, oldfunc) == 0) {
        __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "Hooked: %s", symbol);
        return true;
    }
    __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "Hook failed: %s", symbol);
    return false;
}

void InitGameHooks() {
    if (HooksAttempted) return;
    HooksAttempted = true;

 
    getHostController = (void* (*)(void*))DobbySymbolResolver(LIB, "_ZN14SoldierManager17getHostControllerEv");
    getBodyPosition = (GamePosition (*)(void*))DobbySymbolResolver(LIB, "_ZN17SoldierController15getBodyPositionEv");
    getSoldierView = (void* (*)(void*))DobbySymbolResolver(LIB, "_ZN17SoldierController14getSoldierViewEv");
    getPlayerHP = (int (*)(void*))DobbySymbolResolver(LIB, "_ZN17SoldierController5getHPEv");
    getHostHP = (int (*)(void*))DobbySymbolResolver(LIB, "_ZN21SoldierHostController5getHPEv");
    setHostHP = (void (*)(void*, int))DobbySymbolResolver(LIB, "_ZN21SoldierHostController5setHPEi");
    getMaxPower = (int (*)(void*))DobbySymbolResolver(LIB, "_ZN17SoldierController11getMaxPowerEv");
    getHostPower = (float (*)(void*))DobbySymbolResolver(LIB, "_ZN21SoldierHostController8getPowerEv");
    setHostPower = (void (*)(void*, float))DobbySymbolResolver(LIB, "_ZN21SoldierHostController8setPowerEf");
    setHostFireAngle = (void (*)(void*, float))DobbySymbolResolver(LIB, "_ZN21SoldierHostController12setFireAngleEf");
    setViewFiringAngle = (void (*)(void*, float))DobbySymbolResolver(LIB, "_ZN11SoldierView14setFiringAngleEf");
    getTeamId = (int (*)(void*))DobbySymbolResolver(LIB, "_ZN15CollisionObject9getTeamIdEv");
    isSameTeam = (bool (*)(void*, int))DobbySymbolResolver(LIB, "_ZN21SoldierHostController10isSameTeamEi");
    isPlayerDead = (bool (*)(void*))DobbySymbolResolver(LIB, "_ZN17SoldierController6isDeadEv");
    convertToWorldSpace = (GamePoint (*)(void*, const GamePoint&))DobbySymbolResolver(LIB, "_ZN7cocos2d6CCNode19convertToWorldSpaceERKNS_7CCPointE");
    convertToNodeSpace = (GamePoint (*)(void*, const GamePoint&))DobbySymbolResolver(LIB, "_ZN7cocos2d6CCNode18convertToNodeSpaceERKNS_7CCPointE");
    ccDrawLine = (void (*)(const GamePoint&, const GamePoint&))DobbySymbolResolver(LIB, "_ZN7cocos2d10ccDrawLineERKNS_7CCPointES2_");
    ccDrawColor4B = (void (*)(unsigned char, unsigned char, unsigned char, unsigned char))DobbySymbolResolver(LIB, "_ZN7cocos2d13ccDrawColor4BEhhhh");

    bool ok = true;
    ok = InjectHook("_ZN6Weapon7subAmmoEi", (void*)hk_Weapon_subAmmo, (void**)&old_Weapon_subAmmo) && ok;
    ok = InjectHook("_ZN6Weapon9getDamageEv", (void*)hk_Weapon_getDamage, (void**)&old_Weapon_getDamage) && ok;
    ok = InjectHook("_ZN6Weapon13getReloadTimeEv", (void*)hk_Weapon_getReloadTime, (void**)&old_Weapon_getReloadTime) && ok;
    ok = InjectHook("_ZN6Weapon15getClipCapacityEv", (void*)hk_Weapon_getClipCapacity, (void**)&old_Weapon_getClipCapacity) && ok;


    if (getHostController && getBodyPosition && getSoldierView) {
        ok = InjectHook("_ZN14SoldierManager10updateStepEf", (void*)hk_Manager_updateStep, (void**)&old_Manager_updateStep) && ok;
        ok = InjectHook("_ZN23SoldierRemoteController10updateStepEf", (void*)hk_Remote_updateStep, (void**)&old_Remote_updateStep) && ok;
        ok = InjectHook("_ZN23SoldierRemoteControllerD1Ev", (void*)hk_Remote_destructor, (void**)&old_Remote_destructor) && ok;
    } else {
        ok = false;
    }
    if (convertToWorldSpace && convertToNodeSpace && ccDrawLine && ccDrawColor4B) {
        ok = InjectHook("_ZN5Stage4drawEv", (void*)hk_Stage_draw, (void**)&old_Stage_draw) && ok;
    } else {
        ok = false;
    }
    HActive = ok;
}

void DrawMenu() {
    if (!MOpen) return;

    ImGui::SetNextWindowSize(ImVec2(600, 450), ImGuiCond_FirstUseEver);
    if (ImGui::Begin("Ultimate Mod Menu", &MOpen)) {
        
        ImGui::TextDisabled("Target: %s", LIB);
        ImGui::Separator();

        if (!HActive) {
            ImGui::TextColored(ImVec4(1, 0, 0, 1), HooksAttempted ? "Hook initialization failed" : "Hooks Not Active");
            if (!HooksAttempted && ImGui::Button("Inject Cheats (Auto-Scan)", ImVec2(-1, 40))) {
                InitGameHooks();
            }
        } else {
            ImGui::TextColored(ImVec4(0, 1, 0, 1), "System Ready");
            ImGui::Dummy(ImVec2(0, 10));

            ImGui::Checkbox("Infinite Ammo", &Cheat.InfiniteAmmo);
            ImGui::Checkbox("One Hit Kill (High Damage)", &Cheat.HighDamage);
            ImGui::Checkbox("Instant Reload", &Cheat.InstantReload);
            ImGui::Checkbox("Huge Clip Capacity", &Cheat.MegaClip);
            ImGui::Separator();
            ImGui::Checkbox("Infinite Health", &Cheat.InfiniteHealth);
            ImGui::Checkbox("Infinite Jetpack", &Cheat.InfiniteJetpack);
            ImGui::Checkbox("Aimbot (Nearest Enemy)", &Cheat.Aimbot);
            ImGui::Separator();
            ImGui::Checkbox("ESP Box", &Cheat.EspBox);
            ImGui::Checkbox("ESP Line", &Cheat.EspLine);
            ImGui::Checkbox("ESP Health", &Cheat.EspHealth);
        }

        ImGui::Separator();
        ImGui::Text("Version 1.0 | Built for Android");
    }
    ImGui::End();
}



bool g_GuiIn = false;

#define HOOKAF(ret, func, ...) \
    ret (*orig##func)(__VA_ARGS__); \
    ret my##func(__VA_ARGS__)


HOOKAF(void, Input, void *thiz, void *ex_ab, void *ex_ac) {
    origInput(thiz, ex_ab, ex_ac);
    ImGui_ImplAndroid_HandleInputEvent((AInputEvent*)thiz);
}


void SetupImgui() {
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.DisplaySize = ImVec2((float)ScreenWidth, (float)ScreenHeight);
    
   
    ImGui::StyleColorsDark();
    ImGui::GetStyle().ScaleAllSizes(3.0f); 
    
    ImGui_ImplOpenGL3_Init("#version 100");
}

EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH, &ScreenWidth);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &ScreenHeight);

    if (!g_GuiIn) {
        SetupImgui();
        g_GuiIn = true;
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(ScreenWidth, ScreenHeight);
    ImGui::NewFrame();

    DrawMenu();

    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return old_eglSwapBuffers(dpy, surface);
}

void *imgui_go(void*) {
    void *handle_egl = xdl_open("libEGL.so", XDL_DEFAULT);
    void *handle_input = xdl_open("libinput.so", XDL_DEFAULT);
    void *xdl_sym_egl = xdl_sym(handle_egl, "eglSwapBuffers", nullptr);
    void *xdl_sym_input = xdl_sym(handle_input, "_ZN7android13InputConsumer21initializeMotionEventEPNS_11MotionEventEPKNS_12InputMessageE", nullptr);
    if (xdl_sym_egl) DobbyHook(xdl_sym_egl, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
    if (xdl_sym_input) DobbyHook(xdl_sym_input, (void*)myInput, (void**)&origInput);
    return nullptr;
}

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, imgui_go, NULL);
}

extern "C" jint JNIEXPORT JNI_OnLoad(JavaVM *vm, void *key) {
    return JNI_VERSION_1_6;
}