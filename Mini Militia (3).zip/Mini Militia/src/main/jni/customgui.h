#pragma once

#include "imgui.h"
#include "imgui_internal.h"
#include <map>

namespace CustomGUI
{
    namespace fonts
    {
        ImFont* Main_Font = nullptr;
        ImFont* Regylar = nullptr;
        ImFont* icons;
        ImFont* ico_list = nullptr;
        ImFont* ico = nullptr;
        ImFont* tabFont;
    }
    namespace animations
    {
    float child_anim = 0.f;
    }
    
  /*  bool renderer_tab(const char* icon, const char* text, bool selected)
{
    ImGuiWindow* window = ImGui::GetCurrentWindow();
    if (window->SkipItems)
        return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(text);

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = { 214, 30 };

    const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

    ImGui::ItemSize(size, 0);

    if (!ImGui::ItemAdd(bb, id))
        return false;

    bool hovered, held;
    bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);

    int current_tab;

    if (hovered || held)
        ImGui::SetMouseCursor(9);

    float deltatime = 1.5f * ImGui::GetIO().DeltaTime;
    static std::map<ImGuiID, float> hover_animation;
    auto it_hover = hover_animation.find(id)
        ;
    if (it_hover == hover_animation.end())
    {
        hover_animation.insert({ id, 0.f });
        it_hover = hover_animation.find(id);
    }

    it_hover->second = clamp(it_hover->second + (2.15f * ImGui::GetIO().DeltaTime * (hovered ? 1.f : -1.f)), 0.0f, 0.0f);
    it_hover->second *= ImGui::GetStyle().Alpha;

    static std::map<ImGuiID, float> filled_animation;
    auto it_filled = filled_animation.find(id);

    if (it_filled == filled_animation.end())
    {
        filled_animation.insert({ id, 0.f });
        it_filled = filled_animation.find(id);
    }

    it_filled->second = clamp(it_filled->second + (2.15f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.5f)), it_hover->second, 1.f);
    it_filled->second *= ImGui::GetStyle().Alpha;

    ImGui::PushFont(InterMedium);
    if (selected) {
        ImGui::GetWindowDrawList()->AddRectFilled(ImVec2(bb.Min.x, bb.Min.y), ImVec2(bb.Max.x, bb.Max.y), ImColor(60, 61, 81, int(255 * ImGui::GetStyle().Alpha)), 5);
    }
    ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 5 + 27, bb.Min.y + 7), ImColor(96, 96, 109, int(255 * ImGui::GetStyle().Alpha)), text);

    if (selected)
    {
        ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 5 + 27, bb.Min.y + 7), ImColor(178, 182, 255, int(255 * it_filled->second)), text);
    }
    ImGui::PopFont();

    ImGui::PushFont(IconFont);
    ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 5, bb.Min.y + 4), ImColor(96, 96, 109, int(255 * ImGui::GetStyle().Alpha)), icon);

    if (selected)
    {
        ImGui::GetWindowDrawList()->AddText(ImVec2(bb.Min.x + 5, bb.Min.y + 4), ImColor(178, 182, 255, int(255 * it_filled->second)), icon);
    }
    ImGui::PopFont();

    return pressed;
}*/


    bool Tab(const char* label,const char* icon, const bool selected, const ImVec2& size_arg)
    {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems)
            return false;

        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);

        ImVec2 pos = window->DC.CursorPos;
        ImVec2 size = ImGui::CalcItemSize(size_arg, label_size.x + style.FramePadding.x * 2.0f, label_size.y + style.FramePadding.y * 2.0f);
        const ImRect bb(pos, { pos.x + size.x , pos.y + size.y });

        ImGui::ItemSize(size, style.FramePadding.y);
        if (!ImGui::ItemAdd(bb, id))
            return false;

        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held, NULL);
        
        float deltatime = 1.5f * ImGui::GetIO().DeltaTime;
        static std::map<ImGuiID, float> hover_animation;
        auto it_hover = hover_animation.find(id);
        
        if (it_hover == hover_animation.end())
        {
        hover_animation.insert({ id, 0.f });
        it_hover = hover_animation.find(id);
        }

        it_hover->second = std::clamp(it_hover->second + (2.15f * ImGui::GetIO().DeltaTime *   (hovered ? 1.f : -1.f)), 0.0f, 0.0f);
        it_hover->second *= ImGui::GetStyle().Alpha;

        static std::map<ImGuiID, float> filled_animation;
        auto it_filled = filled_animation.find(id);

        if (it_filled == filled_animation.end())
        {
        filled_animation.insert({ id, 0.f });
        it_filled = filled_animation.find(id);
        }

        it_filled->second = std::clamp(it_filled->second + (2.15f * ImGui::GetIO().DeltaTime * (selected ? 1.f : -1.5f)), it_hover->second, 1.f);
        it_filled->second *= ImGui::GetStyle().Alpha;

        if (selected)
        {
            window->DrawList->AddRectFilled(bb.Min, bb.Max,ImColor(255,98,98,int(255 * ImGui::GetStyle().Alpha)),4.f);
        }
		else
            window->DrawList->AddRectFilled(bb.Min, bb.Max,ImColor(18,18,18,int(255 * ImGui::GetStyle().Alpha)),4.f);		

        ImGui::PushFont(fonts::Main_Font);
        if (selected)
            window->DrawList->AddText({ bb.Min.x + 110,bb.Min.y + size_arg.y / 2 - ImGui::CalcTextSize(label).y / 2  }, ImColor(255,255,255, int(255 * it_filled->second)), label);
        else
            window->DrawList->AddText({ bb.Min.x + 110,bb.Min.y + size_arg.y / 2 - ImGui::CalcTextSize(label).y / 2  }, ImColor(70,70,70, int(255 * ImGui::GetStyle().Alpha)), label);
        ImGui::PopFont();

        ImGui::PushFont(fonts::tabFont);
        if(selected)
            window->DrawList->AddText({ bb.Min.x + 80,bb.Min.y + size_arg.y / 2 - ImGui::CalcTextSize(icon).y / 2 }, ImColor(255,255,255,int(255 * it_filled->second)), icon);
        else
            window->DrawList->AddText({ bb.Min.x + 80,bb.Min.y + size_arg.y/ 2 - ImGui::CalcTextSize(icon).y / 2 }, ImColor(70,70,70,int(255 * ImGui::GetStyle().Alpha)), icon);
        ImGui::PopFont();

        return pressed;
    }
}  
