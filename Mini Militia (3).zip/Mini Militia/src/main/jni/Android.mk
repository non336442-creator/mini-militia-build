LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)
LOCAL_MODULE := dobby
LOCAL_SRC_FILES := lib/$(TARGET_ARCH_ABI)/libdobby.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := foxcheats
LOCAL_SRC_FILES := lib/$(TARGET_ARCH_ABI)/libfoxcheats.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := glosshook
LOCAL_SRC_FILES := lib/$(TARGET_ARCH_ABI)/libGlossHook.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := andinlinehook
LOCAL_SRC_FILES := lib/$(TARGET_ARCH_ABI)/libAndInlineHook.a
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := Lewis
LOCAL_CFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive -fexceptions
LOCAL_CPPFLAGS := -w -s -Wno-error=format-security -fvisibility=hidden -fpermissive -fexceptions -Wall -std=c++17
LOCAL_LDFLAGS += -Wl,--gc-sections,--strip-all
LOCAL_LDLIBS := -llog -landroid -lEGL -lGLESv3
LOCAL_ARM_MODE := arm
LOCAL_C_INCLUDES := \
    $(LOCAL_PATH)/include \
    $(LOCAL_PATH)/include/xdl \
    $(LOCAL_PATH)/include/ImGui \
    $(LOCAL_PATH)/include/ImGui/backends \
    $(LOCAL_PATH)/include/ImGui/theme \
    $(LOCAL_PATH)/include/ImGui/font \
    $(LOCAL_PATH)/include/ImGui/Notify \
    $(LOCAL_PATH)/include/Hook/Dobby \
    $(LOCAL_PATH)/include/Hook/KittyMemory \
    $(LOCAL_PATH)/include/Hook/GlossHook \
    $(LOCAL_PATH)/include/Hook/foxcheats \
    $(LOCAL_PATH)/include/Hook/AndInlineHook \
    $(LOCAL_PATH)/include/Utils \
    $(LOCAL_PATH)/include/Utils/Unity \
    $(LOCAL_PATH)/include/Utils/Unity/il2cpp

FILE_LIST := \
    $(wildcard $(LOCAL_PATH)/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/xdl/*.c) \
    $(wildcard $(LOCAL_PATH)/src/ImGui/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/ImGui/backends/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/Hook/KittyMemory/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/Utils/*.cpp) \
    $(wildcard $(LOCAL_PATH)/src/Utils/Unity/il2cpp/*.cpp)

LOCAL_SRC_FILES := $(FILE_LIST:$(LOCAL_PATH)/%=%)
LOCAL_STATIC_LIBRARIES := dobby foxcheats glosshook andinlinehook
include $(BUILD_SHARED_LIBRARY)