#ifndef INLINE_HOOK_H
#define INLINE_HOOK_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

int Hook(void *func_addr, void *new_addr, void **orig_addr);

#ifdef __cplusplus
}
#endif

#endif
